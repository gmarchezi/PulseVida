/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pulsevida;

/**
 *
 * @author 20161BSI0012
 */
public class FrequenciaCardiaca {
    private int frequencia;
}
