/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package pulsevida;

public class Notificacao {
    private String nomeUsuario;
    private String celularContato;
    private String mensagem;
    private String dataHora;
    private String localizacao;
}
